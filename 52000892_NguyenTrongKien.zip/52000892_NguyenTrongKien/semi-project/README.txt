## Nguyên tắc và mô hình phát triển
Ứng dụng tuân thủ nguyên tắc RESTful và sử dụng mô hình MVC (Model-View-Controller).

## Cấu trúc dự án
semi-project/
|-- src/
|   |-- main/
|       |-- java/
|           |-- com/
|               |-- nguyentrongkien/
|                   |-- semi-project/
|			|-- controller/
|                   	|-- model/
|                   	|-- repository/
|                   	|-- service/
|                   	|-- SpringCommerceApplication.java
|	|-- resources/
|   		|-- application.properties
|	|-- webapp/
|-- database.sql
|-- README.md


## Cấu trúc mã
Dự án được chia thành các gói (packages) như sau:
- `api.admin`: chứa các lớp phân theo vai trò cho admin
- `controller`: Chứa các lớp điều khiển (controllers).
- `dto`: chứa các lớp với mục đích chuyển dữ liệu giữa các lớp như service và controller được hiệu quả hơn
- `entities`: Định nghĩa các đối tượng (entities).
- `repository`: Chứa các giao diện và lớp triển khai của repository.
- `service`: Chứa các dịch vụ (services) và lớp triển khai của chúng.
- `validator`: chứa các lớp có nhiệm vụ kiểm tra tính hợp lệ của dữ liệu
- `webapp`: chứa các file jps, css, js

## Các bước chạy project
1. Sau khi tải về cần click chuột phải vào file pom.xml chọn Maven -> Generate Sources and Update Folders
2. Nếu bước 1 đã thực hiện mà thiếu variables thì có thể click chuột phải vào file pom.xml -> Maven -> Reload project

