package com.nguyentrongkien.semiproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemiprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
