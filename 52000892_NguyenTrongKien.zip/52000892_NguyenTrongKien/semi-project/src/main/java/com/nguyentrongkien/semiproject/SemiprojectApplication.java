package com.nguyentrongkien.semiproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemiprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemiprojectApplication.class, args);
	}

}
