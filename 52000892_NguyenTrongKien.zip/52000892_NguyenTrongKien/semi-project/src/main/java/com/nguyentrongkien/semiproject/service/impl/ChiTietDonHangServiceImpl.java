package com.nguyentrongkien.semiproject.service.impl;

import com.nguyentrongkien.semiproject.entities.ChiTietDonHang;
import com.nguyentrongkien.semiproject.repository.ChiTietDonHangRepository;
import com.nguyentrongkien.semiproject.service.ChiTietDonHangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChiTietDonHangServiceImpl implements ChiTietDonHangService{
	
	@Autowired
	private ChiTietDonHangRepository repo;
	
	@Override
	public List<ChiTietDonHang> save(List<ChiTietDonHang> list)
	{	
		return repo.saveAll(list);
	}
}
