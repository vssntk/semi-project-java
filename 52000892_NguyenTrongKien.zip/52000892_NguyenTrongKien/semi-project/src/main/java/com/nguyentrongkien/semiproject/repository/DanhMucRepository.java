package com.nguyentrongkien.semiproject.repository;

import com.nguyentrongkien.semiproject.entities.DanhMuc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DanhMucRepository extends JpaRepository<DanhMuc, Long>{

}
