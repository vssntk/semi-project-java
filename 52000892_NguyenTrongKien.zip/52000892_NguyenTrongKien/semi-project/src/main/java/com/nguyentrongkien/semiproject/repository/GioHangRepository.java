package com.nguyentrongkien.semiproject.repository;

import com.nguyentrongkien.semiproject.entities.GioHang;
import com.nguyentrongkien.semiproject.entities.NguoiDung;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GioHangRepository extends JpaRepository<GioHang, Long>{
	
	GioHang findByNguoiDung(NguoiDung n);
	
}
