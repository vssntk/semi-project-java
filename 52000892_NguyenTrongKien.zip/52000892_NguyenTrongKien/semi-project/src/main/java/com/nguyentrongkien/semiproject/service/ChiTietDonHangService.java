package com.nguyentrongkien.semiproject.service;

import com.nguyentrongkien.semiproject.entities.ChiTietDonHang;

import java.util.List;

public interface ChiTietDonHangService {
	List<ChiTietDonHang> save(List<ChiTietDonHang> list);
}
