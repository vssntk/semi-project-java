package com.nguyentrongkien.semiproject.service;

import com.nguyentrongkien.semiproject.entities.GioHang;
import com.nguyentrongkien.semiproject.entities.NguoiDung;

public interface GioHangService {
	
	GioHang getGioHangByNguoiDung(NguoiDung n);
	
	GioHang save(GioHang g);
}
