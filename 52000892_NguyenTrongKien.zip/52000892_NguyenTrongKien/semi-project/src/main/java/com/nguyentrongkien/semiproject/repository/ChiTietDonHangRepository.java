package com.nguyentrongkien.semiproject.repository;

import com.nguyentrongkien.semiproject.entities.ChiTietDonHang;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChiTietDonHangRepository extends JpaRepository<ChiTietDonHang, Long>{
}
