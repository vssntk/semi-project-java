package com.nguyentrongkien.semiproject.repository;

import com.nguyentrongkien.semiproject.entities.ChiMucGioHang;
import com.nguyentrongkien.semiproject.entities.GioHang;
import com.nguyentrongkien.semiproject.entities.SanPham;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChiMucGioHangRepository extends JpaRepository<ChiMucGioHang, Long>{
	
	ChiMucGioHang findBySanPhamAndGioHang(SanPham sp,GioHang g);
	
	List<ChiMucGioHang> findByGioHang(GioHang g);
}
