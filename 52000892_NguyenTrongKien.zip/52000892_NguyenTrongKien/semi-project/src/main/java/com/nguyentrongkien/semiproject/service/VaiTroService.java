package com.nguyentrongkien.semiproject.service;

import com.nguyentrongkien.semiproject.entities.VaiTro;

import java.util.List;

public interface VaiTroService {

	VaiTro findByTenVaiTro(String tenVaiTro);
	List<VaiTro> findAllVaiTro();
}
