package com.nguyentrongkien.semiproject.service.impl;

import com.nguyentrongkien.semiproject.entities.VaiTro;
import com.nguyentrongkien.semiproject.repository.VaiTroRepository;
import com.nguyentrongkien.semiproject.service.VaiTroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VaiTroServiceImpl implements VaiTroService{
	

	@Autowired
	private VaiTroRepository repo;

	@Override
	public VaiTro findByTenVaiTro(String tenVaiTro) {
		return repo.findByTenVaiTro(tenVaiTro);
	}

	@Override
	public List<VaiTro> findAllVaiTro() {
		return repo.findAll();
	}


}
