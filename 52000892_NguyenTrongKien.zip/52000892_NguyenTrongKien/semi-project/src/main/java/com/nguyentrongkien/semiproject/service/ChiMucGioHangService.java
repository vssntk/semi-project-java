package com.nguyentrongkien.semiproject.service;

import com.nguyentrongkien.semiproject.entities.ChiMucGioHang;
import com.nguyentrongkien.semiproject.entities.GioHang;
import com.nguyentrongkien.semiproject.entities.SanPham;

import java.util.List;

public interface ChiMucGioHangService{
	
	List<ChiMucGioHang> getChiMucGioHangByGioHang(GioHang g);
	
	ChiMucGioHang getChiMucGioHangBySanPhamAndGioHang(SanPham sp,GioHang g);
	
	ChiMucGioHang saveChiMucGiohang(ChiMucGioHang c);
	
	void deleteChiMucGiohang(ChiMucGioHang c);
	
	void deleteAllChiMucGiohang(List<ChiMucGioHang> c);
	
}
